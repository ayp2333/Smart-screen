#ifndef _DS_WIFI_STATION_H_
#define _DS_WIFI_STATION_H_

void ds_wifi_sta_start(void);
void ds_wifi_sta_stop(void);

#endif


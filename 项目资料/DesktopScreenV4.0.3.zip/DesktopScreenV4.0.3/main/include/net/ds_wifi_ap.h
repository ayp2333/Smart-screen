#ifndef _DS_WIFI_AP_H_
#define _DS_WIFI_AP_H_

void ds_wifi_ap_start(void);
void ds_wifi_ap_stop(void);

#endif


#ifndef _DS_SNTP_H_
#define _DS_SNTP_H_

void initialize_sntp(void);

#endif
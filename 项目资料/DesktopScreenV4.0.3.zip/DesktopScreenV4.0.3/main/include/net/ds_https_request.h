#ifndef _DS_HTTPS_REQUEST_H_
#define _DS_HTTPS_REQUEST_H_

void ds_https_request_init(void);

#endif


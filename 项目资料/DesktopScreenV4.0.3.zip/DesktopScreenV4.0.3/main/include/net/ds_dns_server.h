#ifndef DS_DNS_SERVER_h
#define SD_DNS_SERVER_h

#ifdef __cplusplus
extern "C"
{
#endif

void dns_server_start();
void web_server_start(void);

#ifdef __cplusplus
}
#endif
#endif  

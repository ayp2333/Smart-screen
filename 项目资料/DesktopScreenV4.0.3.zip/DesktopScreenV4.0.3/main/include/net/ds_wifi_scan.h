#ifndef _DS_WIFI_SCAN_H_
#define _DS_WIFI_SCAN_H_

void ds_wifi_scan_start(void);
void ds_wifi_scan_stop(void);

#endif




#ifndef _DS_UI_MAINPAGE_H_
#define _DS_UI_MAINPAGE_H_

void ds_screen_display_main();
void ds_screen_setting();

#endif

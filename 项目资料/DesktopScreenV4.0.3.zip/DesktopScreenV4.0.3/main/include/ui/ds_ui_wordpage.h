#ifndef _DS_UI_WORDPAGE_H_
#define _DS_UI_WORDPAGE_H_

void ds_ui_wordpage_show(uint8_t num);
void ds_ui_wordpage_init();


#endif
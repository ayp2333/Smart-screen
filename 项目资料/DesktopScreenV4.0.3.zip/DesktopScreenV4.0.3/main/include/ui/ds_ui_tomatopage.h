#ifndef _DS_UI_TOAMTOAGE_H_
#define _DS_UI_TOMATOPAGE_H_

void ds_ui_tomatopage_init();
void ds_ui_tomatopage_show_init();
void ds_ui_tomatopage_updatetime();
void ds_ui_tomatopage_time_set(uint8_t minute,uint8_t second,uint8_t times);
void ds_ui_tomatopage_start_toggle();

#endif
#ifndef _DS_DATA_NUM_H_
#define _DS_DATA_NUM_H_

extern unsigned char gImage_num_size48[10][192];
extern unsigned char gImage_time_symbol[36];

extern const unsigned char gImage_num_size24[10][48];

#endif
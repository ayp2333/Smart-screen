
#ifndef _DS_DATA_PAGE_H_
#define _DS_DATA_PAGE_H_

extern const unsigned char gImage_main_page_wifi[];

extern const unsigned char gImage_main_page[];

extern const unsigned char gImage_setting_page[];

#endif

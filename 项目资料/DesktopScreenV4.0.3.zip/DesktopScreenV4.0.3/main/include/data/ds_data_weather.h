#ifndef _DS_DATA_WEATHER_H_
#define _DS_DATA_WEATHER_H_

extern unsigned char gImage_num_weather_icon[7][288];
extern unsigned char gImage_num_weather_code[11][128];
extern const unsigned char gImage_city_guangzhou[288];
extern const unsigned char gImage_city_tianqi[2][128];

#endif
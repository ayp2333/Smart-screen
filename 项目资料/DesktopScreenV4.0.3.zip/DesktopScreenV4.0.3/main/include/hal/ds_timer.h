#ifndef _DS_TIMER_H_
#define _DS_TIMER_H_

void ds_timer_init(void);

#endif

